package com.oocl.game;

/**
 * Created by CHENCO7 on 7/5/2017.
 */
public abstract class Plant {
    //价格
    public abstract void price();
    //耐久度
    public abstract void durable();
    //冷却时间
    public abstract void coolDownTime();
}
