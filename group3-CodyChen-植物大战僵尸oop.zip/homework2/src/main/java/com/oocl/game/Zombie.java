package com.oocl.game;

/**
 * Created by CHENCO7 on 7/5/2017.
 */
public abstract class Zombie {
    //速度
    public abstract void speed();
    //强壮度
    public abstract void strongness();
}
