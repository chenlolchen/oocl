package com.oocl.game;

/**
 * Created by chen on 2017/7/5.
 */
public interface AttackInterface {
    void attack();
    void attackInterval();
    void attackRange();
}
