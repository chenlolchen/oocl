package com.oocl.game;

/**
 * Created by chen on 2017/7/5.
 */
public interface AttackSlowDownInterface {
    void slowDown();
}
