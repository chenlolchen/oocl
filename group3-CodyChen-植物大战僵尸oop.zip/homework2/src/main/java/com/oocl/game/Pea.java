package com.oocl.game;

/**
 * Created by chen on 2017/7/5.
 */
public abstract class Pea extends Plant{
    public abstract void shootPea();
}
